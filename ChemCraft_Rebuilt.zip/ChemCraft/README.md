# ChemCraft

This folder contains the supplied ChemCraft interface, its JavaScript game engine, and the 32-element chemistry database.

## Run locally
Because the game loads JSON with `fetch()`, open the folder through a local web server rather than double-clicking `index.html`.

With Python installed, run this inside the ChemCraft folder:

```bash
python -m http.server 8000
```

Then visit http://localhost:8000

## Deploy
Upload the contents of this folder to the root of a static hosting project (for example, GitHub Pages or Vercel).

## Main files
- `index.html` — supplied ChemCraft interface
- `game.js` — game engine and UI event handling
- `compounds.json`, `reactions.json` — complete database
- `level1_...` through `level5_...` — level-specific database subsets
